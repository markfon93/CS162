#include "Bubba.h"

Bubba::Bubba(){
  healthValue = 12;
  armorValue = 0;
  characterID = 3;
}
