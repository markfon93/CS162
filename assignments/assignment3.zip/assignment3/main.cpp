#include "Character.h"
#include "Game.h"

#include "Bubba.h"
#include "Vampire.h"
#include "Medusa.h"

using namespace std;

int main(){
  Game newGame;
  newGame.startGame();
  return 0;
}
