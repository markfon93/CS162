#ifndef BUBBA_H
#define BUBBA_H
#include "Character.h"

class Bubba : public Character {
  private:

  public:
    Bubba();
};

#endif
