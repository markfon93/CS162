#ifndef PLAYERS_H
#define PLAYERS_H

class Players{
	private:

	public:
		int autoPlayX();
		int autoPlayY();

};

#endif
