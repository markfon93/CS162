#include "GameLogic.h"
#include "Player.h"
#include <iostream>

using namespace std;

void GameLogic::createGameBoard(int rows, int cols, char** gameBoard){
	gameBoard = new char*[rows];
	for (int i = 0; i < rows; i++){
			gameBoard[i] = new char[cols];
		}
	}

void GameLogic::printGameBoard(int rows, int cols, char** gameBoard){

}



/*
~gameBoard(int rows){
	for (int i = 0; i < rows; ++){
		delete[] gameBoard[i];
		delete [] gameBoard;
	}

}*/
