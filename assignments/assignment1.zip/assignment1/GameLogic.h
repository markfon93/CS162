#ifndef GAMELOGIC_H
#define GAMELOGIC_H

class GameLogic {
  private:
    
  public:
    void createGameBoard(int rows, int cols, char** gameBoard);
    void printGameBoard(int rows, int cols, char** gameBoard);
};

#endif
