#include "GameLogic.h"
#include "Player.h"
#include <iostream>

using namespace std;

int main(){
	GameLogic newGame;
	char** gameBoard;
	int rows = 3;
	int cols = 3;

	newGame.createGameBoard(rows, cols, gameBoard);
	newGame.printGameBoard(rows, cols, gameBoard);

	return 0;
};
