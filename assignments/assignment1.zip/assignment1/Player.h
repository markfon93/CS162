#ifndef PLAYER_H
#define PLAYER_H

class Player{
	private:
		bool player1;

	public:
		void player();
		void AIPlayer();
};

#endif
